import * as React from 'react';
import {
  // JupyterLab,
  JupyterFrontEndPlugin,
  JupyterFrontEnd,
} from '@jupyterlab/application';
import {
  ICommandPalette,
  ReactWidget,
} from '@jupyterlab/apputils';
import Tree from './tree';
// import {
//   Widget
// } from '@phosphor/widgets';
// import Tree from './tree';
// import style from '~antd/dist/antd.css';
// import  './index.module.less';

const data = [
  {
    name: '数据预处理',
    id: '00000001-0000-0000-0000-000000000000',
    childrenCount: '2',
    children: [
      {
        moduleId: "a0a782ca-1bc3-4f2e-8202-c34fefd0cdcb",
        moduleVersionId:"f2a6757a-1255-4017-9629-12bf2dd0fc1f",
        name:"APS",
        sourceType:0,
        moduleType:0,
        iconType:1,
        isPrivate:true,
        desc:"11",
      },
      {
        moduleId: "a0a782ca-1bc3-4f2e-8202-c34fefd0cdcb",
        moduleVersionId:"f2a6757a-1255-4017-9629-12bf2dd0fc1f",
        name:"APS2",
        sourceType:0,
        moduleType:0,
        iconType:1,
        isPrivate:true,
        desc:"11",
      }
    ]
  },
  {
    name: '数据预处理2',
    id: '00000001-0000-0000-0000-000000000001',
    childrenCount: '2',
    children: [
      {
        moduleId: "a0a782ca-1bc3-4f2e-8202-c34fefd0cdcb",
        moduleVersionId:"f2a6757a-1255-4017-9629-12bf2dd0fc1f",
        name:"APS3",
        sourceType:0,
        moduleType:0,
        iconType:1,
        isPrivate:true,
        desc:"11",
      },
      {
        moduleId: "a0a782ca-1bc3-4f2e-8202-c34fefd0cdcb",
        moduleVersionId:"f2a6757a-1255-4017-9629-12bf2dd0fc1f",
        name:"APS4",
        sourceType:0,
        moduleType:0,
        iconType:1,
        isPrivate:true,
        desc:"11",
      }
    ],
  }
]

/**
 * Initialization data for the jupyterlab-extension-demo extension.
 */
const extension: JupyterFrontEndPlugin<void> = {
  id: 'jupyterlab-extension-analysis',
  autoStart: true,
  requires: [ICommandPalette],
  activate: (app: JupyterFrontEnd, palette: ICommandPalette) => {
    console.log('JupyterLab extension jupyterlab-extension-analysis is activated!');
    let div = ReactWidget.create(
      <div>
        <Tree treeData={data} />
      </div>
    );
    div.id = 'analysisTree';
    div.title.label = '分析模块';
    app.shell.add(div, 'left', { rank: 200 });
  }
};

export default extension;
